package com.project.repo;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.project.entities.user;

@Repository
public interface UserRepository extends MongoRepository <user,Long > {

	Optional<user> findByEmail(String email);

	Optional<user> findByusername(String username);


	Optional<user> findByUsername(String username);

	user getUserByUsername(String username);

    
}