package com.project.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.project.entities.post;

@Repository
public interface postRepository extends MongoRepository < post,Long > {

	
	List<post> findAllByOrderByCreatedAtDesc();

	Optional<List<post>> findByusernameOrderByCreatedAtDesc(String id);
	Optional<List<post>> findByUsername(String id);
 
	

	

    
}