package com.project.entities;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class userid {
   
	private String id;    
    public userid(String id) {
		super();
		this.id = id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}