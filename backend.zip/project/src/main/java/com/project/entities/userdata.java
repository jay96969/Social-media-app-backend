package com.project.entities;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class userdata {
	@Id
	private String firstname;
	private String lastname;
	private String bio;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public userdata(String firstname, String lastname, String bio) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.bio = bio;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}
	@Override
	public String toString() {
		
		return "{firstname :"+firstname+", lastname:" +lastname+",bio:"+bio+"}";
		
	}

}
