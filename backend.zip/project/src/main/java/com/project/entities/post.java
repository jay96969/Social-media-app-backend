package com.project.entities;

import java.time.Instant;

import javax.persistence.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin
@Document(collection="post")
public class post {
	  
	  @Id
	  private String username;
	  private String caption;
	  private int likes;
	  private int comments;
	  private String createdAt;
	  private String image;
	  
	  
	public post() {
		super();
		// TODO Auto-generated constructor stub
	}
	public post(String username, String caption, int likes, int comments, String createdAt, String image) {
		super();
		this.username = username;
		this.caption = caption;
		this.likes = likes;
		this.comments = comments;
		this.createdAt = createdAt;
		this.image = image;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCaption() {
		return caption;
	}
	public void setCaption(String caption) {
		this.caption = caption;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public int getComments() {
		return comments;
	}
	public void setComments(int comments) {
		this.comments = comments;
	}
	  
	  
}