package com.project.service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.project.entities.user;
import com.project.repo.UserRepository;

@Service
public class userServiceImp implements UserDetailsService{
	    @Autowired
	    private UserRepository userRepo;
	    @Autowired
	    private BCryptPasswordEncoder bCryptEncoder;
	  
	    public ResponseObjectService adduser(user inputUser) {
	    	 ResponseObjectService responseObj = new ResponseObjectService();
	         Optional<user> optUser = userRepo.findByusername(inputUser.getUsername());
	         if (optUser.isPresent()) {
	             responseObj.setStatus("fail");
	             responseObj.setMessage("Email address " + inputUser.getEmail() + " existed");
	             responseObj.setPayload(null);
	             return responseObj;
	         } else {
	        	 inputUser.setPassword(bCryptEncoder.encode(inputUser.getPassword()));
	        	 inputUser.setRole("user");
	             user use = userRepo.save(inputUser);
	             responseObj.setPayload(use);
	             responseObj.setStatus("success");
	             responseObj.setMessage("success");
	             return responseObj;
	         }
	    }
	    public ResponseObjectService update(user use) {
	    	 ResponseObjectService responseObj = new ResponseObjectService();	
	    	     user userExisting =  userRepo.getUserByUsername(use.getUsername());
	             if(userExisting  == null){
	                
	              }
	            userExisting.setFullname(use.getFullname());
				//return serveiceClass.updateUserbyId(userExisting);
	    	     
	             user us = userRepo.save(use);
	             responseObj.setPayload(us);
	             responseObj.setStatus("success");
	             responseObj.setMessage("success");
	             return responseObj;  
	    }
		@Override
		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			Optional<user> optUser = userRepo.findByUsername(username);
	        User springUser = null;

	        if (optUser.isEmpty()) {
	            throw new UsernameNotFoundException("Cannot find user with username: " + username);
	        } else {
	            user foundUser = optUser.get();
	            String role = foundUser.getRole();
	            Set<GrantedAuthority> ga = new HashSet<>();
	            ga.add(new SimpleGrantedAuthority(role));
	            springUser = new User(foundUser.getUsername(), foundUser.getPassword(), ga);
	            return springUser;
	        }
	    }
		

	    
	    
	    
	    

}
