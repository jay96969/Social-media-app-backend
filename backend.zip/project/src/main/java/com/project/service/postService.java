package com.project.service;

import java.time.Instant;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.project.entities.post;
import com.project.entities.userid;
import com.project.repo.UserRepository;
import com.project.repo.postRepository;

@CrossOrigin
@Service
public class postService {
    @Autowired
    private postRepository postRepo;
    @Autowired
    private UserRepository userRepo;
    
    public ResponseObjectService insertPost(post inputPost) {
    	
        ResponseObjectService responseObj = new ResponseObjectService();
     //   inputPost.setCreatedAt(Instant.now());
        responseObj.setStatus("success");
        responseObj.setMessage("success");
        responseObj.setPayload(postRepo.save(inputPost));
        return responseObj;
        
    }
    public ResponseObjectService findPostByUsername(String uname) {
        ResponseObjectService responseObj = new ResponseObjectService();
        Optional<List<post>> userPostsOpt = postRepo.findByUsername(uname);
       
        if (userPostsOpt.isEmpty()) {
            responseObj.setStatus("fail");
            responseObj.setMessage("cannot find any post from user id: " + uname);
            responseObj.setPayload(null);
            return  responseObj;
        } else {
            List<post> userPosts = userPostsOpt.get();
            responseObj.setStatus("success");
            responseObj.setMessage("success");
            responseObj.setPayload(userPosts);
            return responseObj;
        }
    }
    
    public ResponseObjectService findallpost() {
            ResponseObjectService responseObj = new ResponseObjectService();
            List<post> userPosts = postRepo.findAllByOrderByCreatedAtDesc(); 
            responseObj.setStatus("success");
            responseObj.setMessage("success");
            responseObj.setPayload(userPosts);
            return responseObj;
        }
   

    
    
}