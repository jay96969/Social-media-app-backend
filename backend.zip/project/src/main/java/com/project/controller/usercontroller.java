package com.project.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import com.project.config.JWTUtil;
import com.project.entities.AuthorizedEntity;
import com.project.entities.UserSignInEntity;
import com.project.entities.user;
import com.project.repo.UserRepository;
import com.project.service.ResponseObjectService;
import com.project.service.userServiceImp;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping(value = "/template")
public class usercontroller {
	
	
	@Autowired
    private userServiceImp userServic;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private JWTUtil jwtUtil;

    @Autowired
    private AuthenticationManager authenticationManager;
	
    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final MongoTemplate mongoTemplate;

    public usercontroller(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @RequestMapping(value = "", method = RequestMethod.GET)
    public List < user > getAllUsers() {
        logger.info("Getting all Employees.");
        return mongoTemplate.findAll(user.class);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public List<user> getEmployee(@PathVariable("id") String emai) {
        logger.info("Getting user with ID: {}.", emai);
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(emai));
        List<user> users = mongoTemplate.find(query,user.class);
       // user userModel = mongoTemplate.findById(email, user.class);
        return users;
    }
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public ResponseEntity<ResponseObjectService> getEmployee(@RequestBody user userModel) {
     /*   logger.info("Getting user with ID: {}.", field);
        Query query = new Query();
        query.addCriteria(Criteria.where(field+".bio").is(em));
        List<user> users = mongoTemplate.find(query,user.class);
       // user userModel = mongoTemplate.findById(email, user.class);
        * 
        */
        return new ResponseEntity<ResponseObjectService>(userServic.adduser(userModel),HttpStatus.OK);
        
      //  return users;
    }
    
    @PutMapping("/update")
    public ResponseEntity<ResponseObjectService> update(@RequestBody user inputUser) {
        return new ResponseEntity<ResponseObjectService>(userServic.update(inputUser), HttpStatus.OK);
    }
    
    
    @PostMapping("/signin")
    public ResponseEntity<ResponseObjectService> userSignIn(@RequestBody UserSignInEntity inputUser) {
        try {
        	
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(inputUser.getUsername(), inputUser.getPassword()));
            String token = jwtUtil.generateToken(inputUser.getUsername());
         
            Optional<user> optUser = userRepo.findByUsername(inputUser.getUsername());
            user use = optUser.get();
            use.setPassword("");
            return new ResponseEntity<ResponseObjectService>(new ResponseObjectService("success", "authenticated", new AuthorizedEntity(use,token)), HttpStatus.OK);
        } catch (Exception ex) {
        	
            return new ResponseEntity<ResponseObjectService>(new ResponseObjectService("fail", "unauthenticated", null), HttpStatus.OK);
        }
    }
    @GetMapping("/getdata")
    public ResponseEntity<String> testAfterLogin(Principal p) {
        return ResponseEntity.ok("Welcome. You are: " + p.getName());
    }
    
    
}