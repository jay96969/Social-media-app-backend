package com.project.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.entities.post;
import com.project.entities.user;
import com.project.entities.userid;
import com.project.repo.UserRepository;
import com.project.repo.postRepository;
import com.project.service.ResponseObjectService;
import com.project.service.postService;
import com.project.service.userServiceImp;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping(value = "/post")
public class postcontroller {
	
	
    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final MongoTemplate mongoTemplate;
 
    @Autowired
    private postService postser;
    
    public postcontroller(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @RequestMapping(value = "", method = RequestMethod.GET)
    public List < post > getAllpost() {
        logger.info("Getting all Employees.");
        return mongoTemplate.findAll(post.class);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public void addpost(@RequestBody post pos) {
   //     logger.info("Getting user with ID: {}.", field);
         mongoTemplate.save(pos);
        
    }
    @RequestMapping(value = "/mypost", method = RequestMethod.POST)
    public ResponseObjectService getmyposts(@RequestBody String username) {
        logger.info("Getting user with ID: {}.", username);
    //    Query query = new Query();
     //   query.addCriteria(Criteria.where("username").is(username));
     //   List<post> poss = mongoTemplate.find(query,post.class);
     //   return poss;
    	//return mongoTemplate.findAllbyUsername(post.class);
    	return postser.findPostByUsername(username);
    }
    
   
    
}